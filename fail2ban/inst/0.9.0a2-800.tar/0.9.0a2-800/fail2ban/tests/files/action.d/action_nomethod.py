
class TestAction():

    def __init__(self, jail, name):
        pass

    def start(self):
        pass

Action = TestAction
