============
 To-Do List
============

1.0
===

* [IN PROGRESS] Other CalDAV clients supports
* Git storage backend
* Tests


2.0
===

* iCal filters and rights
* CalDAV rights
* CalDAV filters
